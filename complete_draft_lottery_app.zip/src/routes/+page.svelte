<script>
  import InputForm from '$lib/InputForm.svelte';
  import MonteCarloResults from '$lib/MonteCarloResults.svelte';
  import { runMonteCarlo } from '$lib/lottery';

  let teams = [
    { name: '', odds: 0 },
    { name: '', odds: 0 },
    { name: '', odds: 0 },
    { name: '', odds: 0 },
    { name: '', odds: 0 },
    { name: '', odds: 0 },
  ];

  let results = null;
  let numSimulations = 10000;

  function updateTeams(updated) {
    teams = updated;
  }

  function runSim() {
    results = runMonteCarlo(teams, numSimulations);
  }
</script>

<style>
  main {
    max-width: 800px;
    margin: auto;
    padding: 2rem;
    font-family: sans-serif;
    color: #333;
  }

  h1 {
    text-align: center;
    color: #0066cc;
  }

  .controls {
    margin-top: 2rem;
    text-align: center;
  }

  input[type="number"] {
    width: 80px;
    margin-left: 0.5rem;
  }

  button {
    margin-left: 1rem;
    padding: 0.5rem 1rem;
    background-color: #0066cc;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
  }

  button:hover {
    background-color: #004999;
  }
</style>

<main>
  <h1>Fantasy Football Draft Lottery</h1>

  <InputForm {teams} onUpdate={updateTeams} />

  <div class="controls">
    <label>Simulations:</label>
    <input type="number" bind:value={numSimulations} />
    <button on:click={runSim}>Run Simulation</button>
  </div>

  <MonteCarloResults {results} />
</main>
